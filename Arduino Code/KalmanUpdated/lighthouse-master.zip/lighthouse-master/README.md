![Two Lighthouse beacons and a Teensy on a breadboard](https://farm8.static.flickr.com/7336/27747465696_948e961a4c.jpg)

Arduino (Teensy) and Processng library to interface with the HTC Vive
Lighthouse beacons.  Not fully functional yet.

More info: https://trmm.net/Lighthouse


